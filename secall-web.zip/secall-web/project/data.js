// Sample data — feels like real terminal-agent debug history
window.SECALL_DATA = (function () {
  const SESSIONS = [
    {
      id: "0193f8c2", title: "스트림 응답 파싱 깨짐 추적",
      agent: "claude-code", project: "secall", turns: 12, tokens: "8.4k",
      duration: "1h 12m", when: "2시간 전", whenAbs: "2026-05-08 02:14",
      summary: "rust accumulator 가 chunk 경계에서 \\u escape 를 자르며 JSON parse fail. utf-8 boundary-safe split 로 패치.",
      tags: ["bug", "ingest"], fav: false,
    },
    {
      id: "0193f841", title: "rust-embed 빌드 캐시 무효화",
      agent: "claude-code", project: "secall-web", turns: 8, tokens: "5.1k",
      duration: "32m", when: "오늘 09:14", whenAbs: "2026-05-08 09:14",
      summary: "vite dist 갱신이 cargo 캐시에 안 잡혀서 stale binary. build.rs 의 rerun-if-changed=dist 추가.",
      tags: ["build", "infra"], fav: false,
    },
    {
      id: "0193f4a0", title: "TanStack Query stale 정책 정리",
      agent: "codex", project: "secall-web", turns: 24, tokens: "16.2k",
      duration: "2h 04m", when: "어제", whenAbs: "2026-05-07 18:40",
      summary: "session list 가 매 focus 마다 refetch — staleTime 30s, refetchOnWindowFocus 끔. observer pattern 점검.",
      tags: ["perf", "data"], fav: true,
    },
    {
      id: "0193e2c4", title: "semantic search ANN 인덱스 튜닝 — recall vs latency",
      agent: "claude-code", project: "secall", turns: 32, tokens: "22.8k",
      duration: "3h 41m", when: "2일 전", whenAbs: "2026-05-06",
      summary: "M=16, ef_construction=200, ef_search=64 에서 recall@10 = 0.92, p95 18ms. nprobe 4 미만에서 cliff.",
      tags: ["search", "perf"], fav: true,
    },
    {
      id: "0193df01", title: "react-flow custom node 렌더링 deopt",
      agent: "claude-code", project: "secall-web", turns: 14, tokens: "9.6k",
      duration: "1h 03m", when: "3일 전", whenAbs: "2026-05-05",
      summary: "memo 깨지는 path — style prop 이 매 렌더 새 객체. useMemo + nodeTypes 안정화로 60fps 회복.",
      tags: ["perf", "graph"], fav: false,
    },
    {
      id: "0193dac8", title: "Pretendard variable subset 빌드",
      agent: "gemini-cli", project: "secall-web", turns: 4, tokens: "2.1k",
      duration: "18m", when: "4일 전", whenAbs: "2026-05-04",
      summary: "kr-extended subset 만 빌드. woff2 480kb → 142kb. CJK extension 은 별도 chunk.",
      tags: ["fonts", "perf"], fav: false,
    },
    {
      id: "0193d990", title: "daily 자동 생성 프롬프트 리펙터",
      agent: "codex", project: "secall", turns: 18, tokens: "11.4k",
      duration: "1h 28m", when: "4일 전", whenAbs: "2026-05-04",
      summary: "system prompt 를 요약/하이라이트/액션 3-part 분리. 일관성 개선, 출력 길이 평균 1.4k → 920t.",
      tags: ["wiki", "prompt"], fav: false,
    },
    {
      id: "0193d201", title: "obsidian frontmatter 파서 corner case",
      agent: "claude-code", project: "obsidian-secall", turns: 22, tokens: "14.0k",
      duration: "1h 56m", when: "5일 전", whenAbs: "2026-05-03",
      summary: "multi-line value + escaped colon 케이스. yaml-rust 의 implicit typing 끄고 strict mode.",
      tags: ["bug", "wiki"], fav: true,
    },
    {
      id: "0193cf77", title: "tunaflow ingest 파이프라인 병목 — fanout 큐 saturation",
      agent: "codex", project: "tunaflow", turns: 28, tokens: "19.3k",
      duration: "2h 41m", when: "6일 전", whenAbs: "2026-05-02",
      summary: "rabbitmq prefetch=1 → 16. ack timing 재검토, dead-letter retry 5분 backoff.",
      tags: ["perf", "infra"], fav: false,
    },
    {
      id: "0193ce11", title: "graph dagre layout 비동기 마이그레이션",
      agent: "claude.ai", project: "secall", turns: 6, tokens: "3.7k",
      duration: "42m", when: "6일 전", whenAbs: "2026-05-02",
      summary: "동기 layout 이 50+ 노드에서 7s. worker 로 옮김. fallback 동기 path 유지.",
      tags: ["graph", "perf"], fav: false,
    },
    {
      id: "0193c8a3", title: "sse 재연결 백오프 정책",
      agent: "chatgpt", project: "secall", turns: 9, tokens: "5.4k",
      duration: "48m", when: "1주 전", whenAbs: "2026-05-01",
      summary: "exponential 2^n, cap 32s, jitter ±20%. 끊긴 동안 missing event 재요청은 의도적으로 안 함.",
      tags: ["realtime", "infra"], fav: false,
    },
    {
      id: "0193c40e", title: "hotkey conflict — '?' vs textarea",
      agent: "claude-code", project: "secall-web", turns: 5, tokens: "2.4k",
      duration: "22m", when: "1주 전", whenAbs: "2026-04-30",
      summary: "input/textarea focus 일 때 hotkey trigger 막는 가드. composing(IME) 도 체크.",
      tags: ["a11y", "ux"], fav: false,
    },
    {
      id: "0193be20", title: "vault diff 처리 — 병렬 fs.readdir 폭주",
      agent: "claude-code", project: "obsidian-secall", turns: 17, tokens: "12.0k",
      duration: "1h 14m", when: "8일 전", whenAbs: "2026-04-29",
      summary: "tokio::spawn 무제한 → semaphore(64) 로 제한. ENOMEM 사라짐.",
      tags: ["bug", "perf"], fav: false,
    },
    {
      id: "0193b840", title: "ingest dedup — content hash + path tuple",
      agent: "codex", project: "secall", turns: 11, tokens: "7.8k",
      duration: "55m", when: "9일 전", whenAbs: "2026-04-28",
      summary: "동일 내용 다른 위치 케이스. (sha256, normalized_path) 로 unique. migration 스크립트 포함.",
      tags: ["ingest", "data"], fav: false,
    },
    {
      id: "0193b210", title: "wiki cross-link 자동 추출",
      agent: "claude-code", project: "secall", turns: 13, tokens: "9.1k",
      duration: "1h 02m", when: "10일 전", whenAbs: "2026-04-27",
      summary: "[[link]] 자동 생성 — 등장 빈도 + tf-idf 결합. precision 우선으로 threshold 0.18.",
      tags: ["wiki", "search"], fav: false,
    },
    {
      id: "0193ad88", title: "config 마이그레이션 — toml → yaml 후 다시 toml",
      agent: "claude-code", project: "secall", turns: 7, tokens: "4.0k",
      duration: "31m", when: "11일 전", whenAbs: "2026-04-26",
      summary: "yaml indent hell. toml 회귀, deserialize tag 정리. 이전 yaml 파일 자동 변환.",
      tags: ["infra"], fav: false,
    },
  ];

  const TURNS = [
    { i: 1, role: "user", content: "secall serve 띄우면 가끔 파싱 에러 나면서 ingest 가 stuck 됨. 로그에 \"unexpected end of JSON input\" 떨어지는데 chunk 경계 문제 같아." },
    { i: 2, role: "assistant", content: "가능성 두 가지로 좁힙니다:\n\n1) accumulator 에서 byte-wise split — UTF-8 boundary 가 깨질 수 있음\n2) provider 측에서 SSE event 가 분할 도착 — `data: ` prefix 가 두 번 등장\n\n먼저 `web/src/hooks/useSSE.ts` 의 buffer 처리부터 봐도 될까요? 구체적으로 줄 12-34." },
    { i: 3, role: "user", content: "맞아 ingest는 rust 쪽이고 web 의 sse 와는 다른 path. rust src/ingest/streaming.rs 에서:\n```rust\nlet text = std::str::from_utf8(&buf[..n])?;\nfor line in text.split('\\n') { ... }\n```" },
    { i: 4, role: "assistant", content: "여기서 `from_utf8(&buf[..n])` 가 chunk 경계에서 부분 UTF-8 sequence 를 잘라낼 때 panic. 특히 `\\u` escape 가 들어간 한글 응답에서 자주 터짐.\n\n패치 방향:\n- `String::from_utf8_lossy` 는 안 됨 (replacement char 가 들어가서 의미가 깨짐)\n- 정공법: `bytes::BytesMut` 으로 누적, `simdutf8::basic::from_utf8` 으로 boundary-safe split. 마지막 partial 은 다음 read 까지 보관." },
    { i: 5, role: "user", content: "okay. 그럼 read loop 를 어떻게 다시 짤까. 이전 chunk 의 tail 을 다음 iteration 으로 carry over 해야 하는 건 알겠는데 line-buffer 와 compose 가 깔끔하지가 않아." },
    { i: 6, role: "assistant", content: "`tokio_util::codec::LinesCodec` 쓰면 됩니다. UTF-8 boundary + line split 둘 다 처리.\n\n```rust\nuse tokio_util::codec::{FramedRead, LinesCodec};\n\nlet mut frames = FramedRead::new(stream, LinesCodec::new_with_max_length(1 << 20));\nwhile let Some(line) = frames.next().await {\n    let line = line?;            // io + utf-8 errors\n    if line.starts_with(\"data: \") {\n        handle(&line[6..])?;\n    }\n}\n```\n\nmax_length 는 1 MiB 정도로 잡아서 악성 응답 방어. provider 에서 단일 event 가 그 이상은 안 옵니다." },
  ];

  const RELATED = [
    { id: "0193b840", title: "ingest dedup — content hash + path tuple", project: "secall" },
    { id: "0193cf77", title: "tunaflow ingest 파이프라인 병목", project: "tunaflow" },
    { id: "0193c8a3", title: "sse 재연결 백오프 정책", project: "secall" },
  ];

  const PROJECTS = [
    { name: "secall",          updated: "2시간 전", pages: 47, sessions: 218 },
    { name: "secall-web",      updated: "오늘 09:14", pages: 31, sessions: 86 },
    { name: "obsidian-secall", updated: "5일 전", pages: 19, sessions: 42 },
    { name: "tunaflow",        updated: "6일 전", pages: 28, sessions: 64 },
  ];

  const DAILY = [
    {
      project: "secall",
      sessions: [
        { id: "0193f8c2", title: "스트림 응답 파싱 깨짐 추적", agent: "claude-code", turns: 12 },
        { id: "0193e2c4", title: "semantic search ANN 인덱스 튜닝", agent: "claude-code", turns: 32 },
      ],
      diary: "오늘은 secall 의 ingest 안정화에 집중. UTF-8 chunk boundary 문제를 `tokio_util::LinesCodec` 로 정리하면서 같은 패턴이 sse 쪽에도 잠재해 있다는 걸 발견. 다음 작업으로 sse buffer 도 동일 코덱으로 마이그레이션."
    },
    {
      project: "secall-web",
      sessions: [
        { id: "0193f841", title: "rust-embed 빌드 캐시 무효화", agent: "claude-code", turns: 8 },
      ],
      diary: "build cache 가 stale binary 를 만드는 문제. `rerun-if-changed=web/dist` 한 줄로 끝났지만 발견까지 30분."
    },
  ];

  const COMMANDS = [
    {
      key: "sync", label: "Sync",
      desc: "에이전트 로그 디렉터리 스캔 — 새 파일만 가져옵니다.",
      lastRun: "오늘 08:42", lastDuration: "12s", status: "ok",
    },
    {
      key: "ingest", label: "Ingest",
      desc: "수집된 raw 로그를 파싱·정규화하여 SQLite 에 적재.",
      lastRun: "오늘 08:43", lastDuration: "1m 04s", status: "ok",
    },
    {
      key: "wiki", label: "Wiki Update",
      desc: "프로젝트별 위키 페이지를 다시 생성합니다.",
      lastRun: "어제 23:10", lastDuration: "3m 22s", status: "ok",
    },
    {
      key: "graph", label: "Graph Rebuild",
      desc: "시맨틱 그래프 노드/엣지를 재구성합니다.",
      lastRun: "3일 전", lastDuration: "8m 12s", status: "stale",
    },
  ];

  return { SESSIONS, TURNS, RELATED, PROJECTS, DAILY, COMMANDS };
})();
