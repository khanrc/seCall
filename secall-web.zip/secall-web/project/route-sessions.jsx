// route-sessions.jsx — /sessions list + selected detail pane
const { useState: useState_S, useMemo: useMemo_S, useEffect: useEffect_S } = React;

function SearchBar({ q, onQ, mode, onMode }) {
  const [focus, setFocus] = useState_S(false);
  return (
    <div className="sb-wrap">
      <div className={"sb" + (focus ? " sb--focus" : "")}>
        <span className="sb__icon"><IconSearch size={14} /></span>
        <input
          className="sb__input"
          placeholder={mode === "semantic" ? "의미로 검색…" : "세션 검색…"}
          value={q}
          onChange={(e) => onQ(e.target.value)}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
        />
        <span className="sb__kbd">
          {q ? (
            <button className="sb__clear" onClick={() => onQ("")}><IconClose size={11} /></button>
          ) : (
            <kbd className="kbd">/</kbd>
          )}
        </span>
      </div>
      {onMode && (
        <div className="sb__seg sb__seg--row">
          {["keyword", "semantic"].map(m => (
            <button key={m}
              className={"sb__seg-btn" + (mode === m ? " on" : "")}
              onClick={() => onMode(m)}>{m}</button>
          ))}
        </div>
      )}
    </div>
  );
}

function FilterRow({ activeTags, onToggleTag, fav, onFav, agents, activeAgents, onToggleAgent, count }) {
  const allTags = ["bug", "perf", "ingest", "search", "graph", "wiki", "build", "infra", "fonts", "data", "realtime", "ux", "a11y", "prompt"];
  return (
    <div className="filter">
      <div className="filter__row">
        <span className="eyebrow">필터</span>
        <button className={"chip" + (fav ? " chip--on" : "")} onClick={onFav}>
          {fav ? <IconStarFill size={11} /> : <IconStar size={11} />}
          <span>즐겨찾기</span>
        </button>
        {agents.map(a => (
          <button key={a}
            className={"chip" + (activeAgents.includes(a) ? " chip--on" : "")}
            onClick={() => onToggleAgent(a)}>
            <AgentDot agent={a} />
            <span>{a}</span>
          </button>
        ))}
        <span className="filter__count mono">{count}건</span>
      </div>
      <div className="filter__row filter__row--tags">
        {allTags.map(t => (
          <button key={t}
            className={"tag" + (activeTags.includes(t) ? " tag--active" : "")}
            onClick={() => onToggleTag(t)}>
            <span style={{ opacity: .55, marginRight: 2 }}>#</span>{t}
          </button>
        ))}
      </div>
    </div>
  );
}

function SessionListItem({ s, selected, onSelect, onFav }) {
  return (
    <li
      className={"sli" + (selected ? " sli--on" : "")}
      onClick={() => onSelect(s.id)}
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") onSelect(s.id); }}
    >
      <div className="sli__head">
        <AgentDot agent={s.agent} />
        <span className="sli__project mono">{s.project}</span>
        <span className="sli__sep">·</span>
        <span className="sli__when">{s.when}</span>
        <button className={"sli__fav" + (s.fav ? " on" : "")}
          onClick={(e) => { e.stopPropagation(); onFav(s.id); }}
          aria-label="즐겨찾기">
          {s.fav ? <IconStarFill size={12} /> : <IconStar size={12} />}
        </button>
      </div>
      <div className="sli__title">{s.title}</div>
      <div className="sli__summary">{s.summary}</div>
      <div className="sli__foot">
        <span className="sli__turns mono">{s.turns} turns</span>
        <span className="sli__sep">·</span>
        <span className="sli__tokens mono">{s.tokens}</span>
        <div className="sli__tags">
          {s.tags.map(t => <span key={t} className="tag tag--xs"><span style={{opacity:.55}}>#</span>{t}</span>)}
        </div>
      </div>
    </li>
  );
}

function MiniChart({ data, label }) {
  const max = Math.max(...data);
  return (
    <div className="mc">
      <div className="mc__label eyebrow">{label}</div>
      <svg viewBox={`0 0 ${data.length * 8} 24`} className="mc__svg" preserveAspectRatio="none">
        {data.map((v, i) => {
          const h = (v / max) * 22;
          return <rect key={i} x={i * 8} y={24 - h} width="6" height={h} rx="1" />;
        })}
      </svg>
    </div>
  );
}

function SessionDetailPane({ session }) {
  if (!session) {
    return (
      <div className="pane pane--empty">
        <div className="empty">
          <div className="empty__art">
            <svg viewBox="0 0 80 60" width="80" height="60" fill="none" stroke="currentColor" strokeWidth="1">
              <rect x="6" y="10" width="32" height="6" rx="1" opacity=".4" />
              <rect x="6" y="20" width="44" height="4" rx="1" opacity=".25" />
              <rect x="6" y="28" width="38" height="4" rx="1" opacity=".25" />
              <rect x="42" y="10" width="32" height="44" rx="2" opacity=".4" />
              <path d="M48 22h20M48 28h20M48 34h14M48 40h18" opacity=".25" />
            </svg>
          </div>
          <h3 className="empty__title">세션을 선택하세요</h3>
          <p className="empty__body">왼쪽 리스트에서 항목을 클릭하면 turns, mini-chart, related sessions 가 여기에 펼쳐집니다.</p>
          <div className="empty__hints">
            <span><kbd className="kbd">j</kbd> <kbd className="kbd">k</kbd> 이동</span>
            <span><kbd className="kbd">/</kbd> 검색</span>
            <span><kbd className="kbd">f</kbd> 즐겨찾기</span>
          </div>
        </div>
      </div>
    );
  }
  const turns = window.SECALL_DATA.TURNS;
  const turnsBars = [3, 5, 4, 8, 6, 7, 9, 12, 10, 8, 11, 9];
  return (
    <div className="pane pane--read">
      <div className="pane__head">
        <div className="pane__crumbs">
          <button className="pane__back"><IconArrowL size={13} /> 리스트</button>
          <span className="pane__sep">/</span>
          <AgentDot agent={session.agent} />
          <span className="pane__agent">{session.agent}</span>
          <span className="pane__sep">/</span>
          <span className="pane__proj mono">{session.project}</span>
        </div>
        <div className="pane__actions">
          <button className="btn btn--ghost"><IconStar size={13} /> 즐겨찾기</button>
          <button className="btn btn--ghost">노트</button>
          <button className="btn btn--primary">위키로 추가</button>
        </div>
      </div>

      <div className="pane__title-row">
        <h1 className="pane__title">{session.title}</h1>
        <div className="pane__meta">
          <span className="mono">{session.id}</span>
          <span className="pane__sep">·</span>
          <span>{session.whenAbs}</span>
          <span className="pane__sep">·</span>
          <span>{session.duration}</span>
        </div>
      </div>

      <div className="pane__cols">
        <div className="pane__main">
          <div className="prose">
            {turns.map(t => (
              <article key={t.i} className="turn">
                <div className="turn__head">
                  <span className={"turn__role turn__role--" + t.role}>
                    {t.role === "user" ? "User" : "Assistant"}
                  </span>
                  <span className="turn__num mono">turn {t.i}</span>
                </div>
                <div className="turn__body">
                  {t.content.split(/```/).map((seg, i) => (
                    i % 2 === 1
                      ? <pre key={i} className="code"><code>{seg.replace(/^[a-z]+\n/, "")}</code></pre>
                      : <div key={i}>{seg.split("\n").map((ln, j) => <p key={j} style={ln ? null : { height: 8 }}>{ln}</p>)}</div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>

        <aside className="pane__side">
          <div className="card">
            <div className="card__hd">
              <span className="eyebrow">메타</span>
            </div>
            <div className="kv">
              <div className="kv__row"><span>Turns</span><b className="mono">{session.turns}</b></div>
              <div className="kv__row"><span>Tokens</span><b className="mono">{session.tokens}</b></div>
              <div className="kv__row"><span>Duration</span><b className="mono">{session.duration}</b></div>
              <div className="kv__row"><span>Agent</span><b><AgentDot agent={session.agent} /> {session.agent}</b></div>
            </div>
          </div>

          <div className="card">
            <div className="card__hd"><span className="eyebrow">턴 분포</span></div>
            <MiniChart data={turnsBars} label="words / turn" />
          </div>

          <div className="card">
            <div className="card__hd">
              <span className="eyebrow">Related</span>
              <button className="card__more">전체</button>
            </div>
            <ul className="related">
              {window.SECALL_DATA.RELATED.map(r => (
                <li key={r.id} className="related__item">
                  <div className="related__title">{r.title}</div>
                  <div className="related__meta mono">{r.project} · {r.id}</div>
                </li>
              ))}
            </ul>
          </div>

          <div className="card">
            <div className="card__hd">
              <span className="eyebrow">노트</span>
              <span className="card__hint mono"><kbd className="kbd">e</kbd></span>
            </div>
            <textarea className="note" placeholder="이 세션에 대한 메모…"
              defaultValue="LinesCodec 패치는 sse 쪽에도 동일하게 필요. 다음 작업으로 옮길 것."
            />
          </div>
        </aside>
      </div>
    </div>
  );
}

function RouteSessions({ selectedId, onSelect, q, mode }) {
  const all = window.SECALL_DATA.SESSIONS;
  const [tags, setTags] = useState_S([]);
  const [agents, setAgents] = useState_S([]);
  const [fav, setFav] = useState_S(false);
  const [favs, setFavs] = useState_S(() => Object.fromEntries(all.map(s => [s.id, s.fav])));

  const filtered = useMemo_S(() => all.filter(s => {
    if (q && !(s.title + s.summary + s.project).toLowerCase().includes(q.toLowerCase())) return false;
    if (tags.length && !tags.every(t => s.tags.includes(t))) return false;
    if (agents.length && !agents.includes(s.agent)) return false;
    if (fav && !favs[s.id]) return false;
    return true;
  }), [q, tags, agents, fav, favs, all]);

  const session = filtered.find(s => s.id === selectedId)
                  || all.find(s => s.id === selectedId);

  const allAgents = ["claude-code", "codex", "gemini-cli", "claude.ai", "chatgpt"];

  return (
    <div className="layout-2pane">
      <aside className="col-list" data-screen-label="01 sessions / list">
        <div className="sl">
          {filtered.length === 0 ? (
            <div className="sl__empty">
              <div className="eyebrow">결과 없음</div>
              <div>다른 키워드로 시도하거나 필터를 비워보세요.</div>
            </div>
          ) : (
            <SessionTree
              sessions={filtered}
              selectedId={selectedId}
              onSelect={onSelect}
              favs={favs}
              onFav={(id) => setFavs({ ...favs, [id]: !favs[id] })}
            />
          )}
        </div>
        <div className="col-list__bottom">
          <CollapsibleFilter
            activeTags={tags}
            onToggleTag={(t) => setTags(tags.includes(t) ? tags.filter(x => x !== t) : [...tags, t])}
            fav={fav} onFav={() => setFav(!fav)}
            agents={allAgents} activeAgents={agents}
            onToggleAgent={(a) => setAgents(agents.includes(a) ? agents.filter(x => x !== a) : [...agents, a])}
            count={filtered.length}
          />
        </div>
      </aside>
      <main className="col-read" data-screen-label="01 sessions / detail">
        <SessionDetailPane session={session} />
      </main>
    </div>
  );
}

window.RouteSessions = RouteSessions;
