// layout.jsx — shell, top nav, JobBanner, HotkeyDialog, icons, primitives
const { useState, useEffect, useRef, useMemo, useCallback } = React;

/* ---------- icons (inline SVG, 16px stroke 1.5) ---------- */
const I = (d, opts = {}) => ({ size = 16, ...rest } = {}) => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="none"
       stroke="currentColor" strokeWidth={opts.sw || 1.5}
       strokeLinecap="round" strokeLinejoin="round" {...rest}>{d}</svg>
);
const IconSearch    = I(<><circle cx="7" cy="7" r="4.5"/><path d="m11 11 3 3"/></>);
const IconStar      = I(<path d="M8 1.8 9.85 5.6l4.2.6L11 9.18l.72 4.18L8 11.4 4.28 13.36 5 9.18 1.95 6.2l4.2-.6z"/>);
const IconStarFill  = ({ size = 16, ...r }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="currentColor" {...r}>
    <path d="M8 1.8 9.85 5.6l4.2.6L11 9.18l.72 4.18L8 11.4 4.28 13.36 5 9.18 1.95 6.2l4.2-.6z"/>
  </svg>
);
const IconHash      = I(<><path d="M3 6h10M3 10h10M6 3 5 13M11 3l-1 10"/></>);
const IconClose     = I(<><path d="m4 4 8 8M12 4l-8 8"/></>);
const IconKeyboard  = I(<><rect x="1.5" y="4" width="13" height="8" rx="1.5"/><path d="M4 7h.01M7 7h.01M10 7h.01M13 7h.01M5 9.6h6"/></>);
const IconSun       = I(<><circle cx="8" cy="8" r="2.8"/><path d="M8 1.5v1.5M8 13v1.5M14.5 8H13M3 8H1.5M12.6 3.4l-1 1M5.4 11.6l-1 1M12.6 12.6l-1-1M5.4 4.4l-1-1"/></>);
const IconMoon      = I(<path d="M13.5 9.5A6 6 0 0 1 6.5 2.5a6 6 0 1 0 7 7Z"/>);
const IconArrowR    = I(<path d="M3 8h10m-4-4 4 4-4 4"/>);
const IconArrowL    = I(<path d="M13 8H3m4-4-4 4 4 4"/>);
const IconChev      = I(<path d="m4 6 4 4 4-4"/>);
const IconCheck     = I(<path d="m3 8 3 3 7-7"/>);
const IconStop      = I(<rect x="4" y="4" width="8" height="8" rx="1"/>);
const IconPlay      = I(<path d="M5 3.5v9l8-4.5z" fill="currentColor"/>, { sw: 0 });
const IconLoader    = ({ size = 14 }) => (
  <span className="loader" style={{ width: size, height: size }} aria-hidden />
);

/* ---------- agent dot ---------- */
function AgentDot({ agent, size = 6 }) {
  const map = {
    "claude-code": "var(--agent-claude-code)",
    "codex":       "var(--agent-codex)",
    "gemini-cli":  "var(--agent-gemini)",
    "claude.ai":   "var(--agent-claude-ai)",
    "chatgpt":     "var(--agent-chatgpt)",
  };
  return (
    <span style={{
      display: "inline-block", width: size, height: size, borderRadius: 999,
      background: map[agent] || "var(--text-3)", flexShrink: 0,
    }} />
  );
}

/* ---------- tag ---------- */
function Tag({ children, onClick, active, removable, onRemove }) {
  return (
    <span className={"tag" + (active ? " tag--active" : "")} onClick={onClick}>
      <span style={{ opacity: .6, marginRight: 3 }}>#</span>{children}
      {removable && <button className="tag__x" onClick={(e) => { e.stopPropagation(); onRemove?.(); }}><IconClose size={9} /></button>}
    </span>
  );
}

/* ---------- header search ---------- */
function HeaderSearch({ q, onQ, mode, onMode, modes }) {
  const [focus, setFocus] = useState(false);
  return (
    <div className={"hsb" + (focus ? " hsb--focus" : "")}>
      <span className="hsb__icon"><IconSearch size={13} /></span>
      <input
        className="hsb__input"
        placeholder={mode === "semantic" ? "의미로 검색…" : mode === "hybrid" ? "전체 검색…" : "검색…"}
        value={q}
        onChange={(e) => onQ(e.target.value)}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
      />
      {q ? (
        <button className="hsb__clear" onClick={() => onQ("")}><IconClose size={10} /></button>
      ) : (
        <kbd className="kbd hsb__kbd">/</kbd>
      )}
      {modes && (
        <div className="hsb__seg">
          {modes.map(m => (
            <button key={m} title={m}
              className={"hsb__seg-btn" + (mode === m ? " on" : "")}
              onClick={() => onMode(m)}>{m[0].toUpperCase()}</button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- generic tree section (reusable group card) ---------- */
function TreeSection({ title, count, badge, defaultOpen = true, variant, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={"trees" + (variant ? " trees--" + variant : "") + (open ? " trees--open" : "")}>
      <button className="trees__h" onClick={() => setOpen(!open)}>
        <IconChev size={10} className={"trees__chev" + (open ? " trees__chev--open" : "")} />
        <span className="trees__name mono">{title}</span>
        {badge != null && <span className="trees__badge mono">{badge}</span>}
        <span className="trees__spacer" />
        {count != null && <span className="trees__count mono">{count}</span>}
      </button>
      {open && <div className="trees__body">{children}</div>}
    </div>
  );
}

/* ---------- collapsible filter (card section variant) ---------- */
function CollapsibleFilter({ activeTags, onToggleTag, fav, onFav, agents, activeAgents, onToggleAgent, count }) {
  const allTags = ["bug", "perf", "ingest", "search", "graph", "wiki", "build", "infra", "fonts", "data", "realtime", "ux", "a11y", "prompt"];
  const active = activeTags.length + activeAgents.length + (fav ? 1 : 0);
  return (
    <TreeSection title="필터"
      badge={active > 0 ? active : null}
      count={count + "건"}
      defaultOpen={false}
      variant="filter">
      <div className="cf__line">
        <button className={"chip" + (fav ? " chip--on" : "")} onClick={onFav}>
          {fav ? <IconStarFill size={11} /> : <IconStar size={11} />}
          <span>즐겨찾기</span>
        </button>
        {agents.map(a => (
          <button key={a}
            className={"chip" + (activeAgents.includes(a) ? " chip--on" : "")}
            onClick={() => onToggleAgent(a)}>
            <AgentDot agent={a} />
            <span>{a}</span>
          </button>
        ))}
      </div>
      <div className="cf__line cf__line--tags">
        {allTags.map(t => (
          <button key={t}
            className={"tag" + (activeTags.includes(t) ? " tag--active" : "")}
            onClick={() => onToggleTag(t)}>
            <span style={{ opacity: .55, marginRight: 2 }}>#</span>{t}
          </button>
        ))}
      </div>
    </TreeSection>
  );
}

/* ---------- session tree (uses TreeSection per project) ---------- */
function SessionTree({ sessions, selectedId, onSelect, favs, onFav }) {
  const groups = useMemo(() => {
    const m = new Map();
    sessions.forEach(s => {
      if (!m.has(s.project)) m.set(s.project, []);
      m.get(s.project).push(s);
    });
    return [...m.entries()];
  }, [sessions]);
  return (
    <div className="tree">
      {groups.map(([project, items]) => (
        <TreeSection key={project} title={project} count={items.length}>
          <ul className="tree__list">
            {items.map(s => (
              <li key={s.id}
                className={"tree__row" + (s.id === selectedId ? " tree__row--on" : "")}
                onClick={() => onSelect(s.id)}>
                <span className="tree__rail" />
                <AgentDot agent={s.agent} />
                <span className="tree__title">{s.title}</span>
                <span className="tree__when mono">{s.when}</span>
                <button
                  className={"tree__fav" + (favs[s.id] ? " on" : "")}
                  onClick={(e) => { e.stopPropagation(); onFav(s.id); }}
                  aria-label="즐겨찾기">
                  {favs[s.id] ? <IconStarFill size={10} /> : <IconStar size={10} />}
                </button>
              </li>
            ))}
          </ul>
        </TreeSection>
      ))}
    </div>
  );
}

/* ---------- top nav ---------- */
function TopNav({ route, onRoute, onTheme, dark, onHotkey, searchSlot }) {
  const items = [
    { k: "sessions", label: "Sessions", k2: "g s" },
    { k: "wiki",     label: "Wiki",     k2: "g w" },
    { k: "daily",    label: "Daily",    k2: "g d" },
    { k: "graph",    label: "Graph",    k2: "g g" },
    { k: "commands", label: "Commands", k2: "g c" },
  ];
  return (
    <header className="nav">
      <div className="nav__left">
        <div className="nav__brand">
          <span className="nav__logo">
            <span className="nav__dot" />
            <span>secall</span>
          </span>
          <span className="nav__build mono">v0.4.2</span>
        </div>
        <nav className="nav__items" aria-label="Primary">
          {items.map(it => (
            <button key={it.k}
              className={"nav__item" + (route === it.k ? " nav__item--on" : "")}
              onClick={() => onRoute(it.k)}>
              {it.label}
            </button>
          ))}
        </nav>
      </div>
      <div className="nav__center">{searchSlot}</div>
      <div className="nav__right">
        <button className="nav__icon" title="단축키 (?)" onClick={onHotkey}><IconKeyboard /></button>
        <button className="nav__icon" title={dark ? "라이트" : "다크"} onClick={onTheme}>
          {dark ? <IconSun /> : <IconMoon />}
        </button>
      </div>
    </header>
  );
}

/* ---------- JobBanner ---------- */
function JobBanner({ job, onCancel }) {
  if (!job) return null;
  const pct = Math.round(job.progress * 100);
  return (
    <div className="jobbanner" role="status">
      <div className="jobbanner__inner">
        <span className="jobbanner__pulse" />
        <span className="jobbanner__label">
          <b>{job.label}</b>
          <span className="jobbanner__phase">{job.phase}</span>
        </span>
        <div className="jobbanner__bar">
          <div className="jobbanner__bar-fill" style={{ width: pct + "%" }} />
        </div>
        <span className="jobbanner__pct mono">{pct}%</span>
        <button className="jobbanner__cancel" onClick={onCancel}>취소</button>
      </div>
    </div>
  );
}

/* ---------- HotkeyHelpDialog ---------- */
function HotkeyHelpDialog({ open, onClose }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  const groups = [
    { title: "Navigation", rows: [
      ["g s", "Sessions"], ["g w", "Wiki"], ["g d", "Daily"],
      ["g g", "Graph"], ["g c", "Commands"], ["⌘ K", "팔레트"],
    ]},
    { title: "List", rows: [
      ["j / k", "다음 / 이전"], ["enter", "열기"], ["f", "즐겨찾기 토글"],
      ["e", "노트"], ["t", "태그"],
    ]},
    { title: "Search", rows: [
      ["/", "검색 포커스"], ["⌘ ↵", "semantic 토글"], ["esc", "닫기"],
    ]},
  ];
  return (
    <div className="dlg" onClick={onClose}>
      <div className="dlg__panel" onClick={(e) => e.stopPropagation()}>
        <div className="dlg__hd">
          <h2 className="dlg__title">단축키</h2>
          <button className="dlg__x" onClick={onClose}><IconClose /></button>
        </div>
        <div className="dlg__body">
          {groups.map(g => (
            <section key={g.title} className="hk-grp">
              <div className="eyebrow">{g.title}</div>
              <ul className="hk-list">
                {g.rows.map(([k, label]) => (
                  <li key={k} className="hk-row">
                    <span>{label}</span>
                    <span className="hk-keys">
                      {k.split(" ").map((p, i) => (
                        <React.Fragment key={i}>
                          {i > 0 && <span className="hk-sep">{p === "/" ? "" : "·"}</span>}
                          <kbd className="kbd">{p}</kbd>
                        </React.Fragment>
                      ))}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- toast ---------- */
function Toast({ toast, onDone }) {
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(onDone, 3200);
    return () => clearTimeout(id);
  }, [toast, onDone]);
  if (!toast) return null;
  return (
    <div className={"toast toast--" + (toast.kind || "ok")}>
      <span className="toast__dot" />
      <span className="toast__msg">{toast.msg}</span>
    </div>
  );
}

Object.assign(window, {
  IconSearch, IconStar, IconStarFill, IconHash, IconClose, IconKeyboard,
  IconSun, IconMoon, IconArrowR, IconArrowL, IconChev, IconCheck, IconStop,
  IconPlay, IconLoader, AgentDot, Tag, TopNav, HeaderSearch, JobBanner,
  HotkeyHelpDialog, Toast, CollapsibleFilter, SessionTree, TreeSection,
});
