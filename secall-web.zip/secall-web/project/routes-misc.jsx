// route-daily.jsx + route-graph.jsx + route-commands.jsx
const { useState: useState_D } = React;

function RouteDaily() {
  const days = [
    { d: "2026-05-08", w: "금", count: 3, turns: 18 },
    { d: "2026-05-07", w: "목", count: 5, turns: 24 },
    { d: "2026-05-06", w: "수", count: 2, turns: 12 },
    { d: "2026-05-05", w: "화", count: 4, turns: 22 },
    { d: "2026-05-04", w: "월", count: 1, turns:  8 },
  ];
  const [day, setDay] = useState_D("2026-05-08");
  const data = window.SECALL_DATA.DAILY;
  const TS = window.TreeSection;
  return (
    <div className="layout-2pane" data-screen-label="04 daily">
      <aside className="col-list">
        <div className="sl">
          <div className="tree">
            <TS title="이번 주" count="5월 1주차">
              <ul className="tree__list">
                {days.map(it => (
                  <li key={it.d}
                    className={"tree__row" + (day === it.d ? " tree__row--on" : "")}
                    onClick={() => setDay(it.d)}>
                    <span className="tree__rail" />
                    <span className="tree__weekday mono">{it.w}</span>
                    <span className="tree__title mono">{it.d}</span>
                    <span className="tree__when mono">{it.count}/{it.turns}t</span>
                  </li>
                ))}
              </ul>
            </TS>
            <TS title="지난 주" count={5} defaultOpen={false}>
              <ul className="tree__list">
                {["2026-05-02","2026-05-01","2026-04-30","2026-04-29","2026-04-28"].map(d => (
                  <li key={d} className="tree__row" onClick={() => setDay(d)}>
                    <span className="tree__rail" />
                    <span className="tree__title mono">{d}</span>
                    <span className="tree__when mono">·</span>
                  </li>
                ))}
              </ul>
            </TS>
          </div>
        </div>
      </aside>
      <main className="col-read">
        <div className="pane pane--read pane--prose">
          <div className="pane__head pane__head--wiki">
            <div className="pane__crumbs">
              <span className="eyebrow">Daily</span>
              <span className="pane__sep">/</span>
              <span className="pane__proj mono">{day}</span>
            </div>
            <div className="pane__actions">
              <button className="btn btn--ghost">vault</button>
              <button className="btn btn--ghost">재생성</button>
            </div>
          </div>

          <article className="prose prose--wiki">
            <h1>금요일 요약</h1>
            <p>오늘은 secall 의 ingest 안정화 + 빌드 캐시 정리에 집중했습니다. 두 작업 모두 발견까지가 길었고, 패치는 짧았습니다.</p>

            {data.map(d => (
              <section key={d.project} className="day">
                <h2><span className="day__proj mono">{d.project}</span></h2>
                <ul className="day__sessions">
                  {d.sessions.map(s => (
                    <li key={s.id} className="day__s">
                      <AgentDot agent={s.agent} />
                      <span className="day__s-title">{s.title}</span>
                      <span className="day__s-meta mono">{s.turns} turns · {s.id}</span>
                    </li>
                  ))}
                </ul>
                <div className="day__diary">
                  <div className="eyebrow">자동 일기</div>
                  <p>{d.diary}</p>
                </div>
              </section>
            ))}

            <h2>내일</h2>
            <ul>
              <li>sse buffer 도 LinesCodec 로 마이그레이션</li>
              <li>daily 자동 일기의 system prompt 검증 (3-part split 결과 비교)</li>
              <li>graph rebuild 백로그 처리 (마지막 실행 3일 전)</li>
            </ul>
          </article>
        </div>
      </main>
    </div>
  );
}

/* ---------- Graph (Obsidian-style force layout) ---------- */
function RouteGraph() {
  const [hover, setHover] = useState_D(null);
  const [filters, setFilters] = useState_D({ project: true, topic: true, session: true });
  const [showLabels, setShowLabels] = useState_D(true);

  // Pre-baked positions chosen to feel like a settled force simulation:
  // 4 loose project hubs scattered, topics drift between them, sessions
  // feather out at the periphery. Slight noise makes it organic.
  const NODES = [
    // projects (hubs)
    { id: "secall",          x: 360, y: 290, type: "project" },
    { id: "secall-web",      x: 600, y: 250, type: "project" },
    { id: "obsidian-secall", x: 280, y: 130, type: "project" },
    { id: "tunaflow",        x: 720, y: 410, type: "project" },
    // topics
    { id: "ingest",      x: 430, y: 360, type: "topic" },
    { id: "search",      x: 295, y: 380, type: "topic", label: "search · ann" },
    { id: "graph-topic", x: 470, y: 220, type: "topic", label: "graph" },
    { id: "perf",        x: 540, y: 350, type: "topic" },
    { id: "build",       x: 660, y: 180, type: "topic", label: "build · cache" },
    { id: "wiki",        x: 220, y: 220, type: "topic", label: "wiki · parser" },
    { id: "realtime",    x: 410, y: 130, type: "topic" },
    { id: "fonts",       x: 660, y: 320, type: "topic" },
    { id: "infra",       x: 760, y: 320, type: "topic" },
    { id: "ux",          x: 540, y: 100, type: "topic" },
    // sessions (smaller, feather out)
    { id: "0193f8c2", x: 500, y: 410, type: "session", label: "LinesCodec" },
    { id: "0193e2c4", x: 235, y: 460, type: "session", label: "ann tuning" },
    { id: "0193df01", x: 410, y: 195, type: "session", label: "react-flow" },
    { id: "0193f841", x: 740, y: 130, type: "session", label: "build cache" },
    { id: "0193cf77", x: 800, y: 470, type: "session", label: "tunaflow ingest" },
    { id: "0193d201", x: 130, y: 180, type: "session", label: "frontmatter" },
    { id: "0193b210", x: 145, y: 290, type: "session", label: "cross-link" },
    { id: "0193c8a3", x: 380, y: 60,  type: "session", label: "sse backoff" },
    { id: "0193dac8", x: 660, y: 80,  type: "session", label: "subset font" },
    { id: "0193ce11", x: 555, y: 175, type: "session", label: "dagre worker" },
    { id: "0193c40e", x: 615, y: 50,  type: "session", label: "hotkey IME" },
    { id: "0193b840", x: 350, y: 470, type: "session", label: "dedup" },
    { id: "0193be20", x: 95,  y: 110, type: "session", label: "vault diff" },
    { id: "0193d990", x: 440, y: 30,  type: "session", label: "daily prompt" },
    { id: "0193ad88", x: 280, y: 50,  type: "session", label: "config toml" },
    { id: "0193f4a0", x: 690, y: 250, type: "session", label: "tanstack stale" },
    { id: "s-perf-1",  x: 540, y: 470, type: "session", label: "rabbit prefetch" },
    { id: "s-graph-1", x: 580, y: 295, type: "session", label: "memo path" },
    { id: "s-srch-1",  x: 175, y: 410, type: "session", label: "tf-idf threshold" },
    { id: "s-wiki-1",  x: 110, y: 350, type: "session", label: "vault writer" },
    { id: "s-rt-1",    x: 350, y: 165, type: "session", label: "reconnect" },
    { id: "s-ui-1",    x: 470, y: 80,  type: "session", label: "key handler" },
  ];
  const EDGES = [
    // project ↔ topic (the structural backbone)
    ["secall", "ingest"], ["secall", "search"], ["secall", "perf"], ["secall", "wiki"],
    ["secall", "graph-topic"], ["secall", "realtime"],
    ["secall-web", "build"], ["secall-web", "perf"], ["secall-web", "ux"], ["secall-web", "fonts"],
    ["obsidian-secall", "wiki"],
    ["tunaflow", "ingest"], ["tunaflow", "infra"], ["tunaflow", "perf"],
    // topic cross-links (cluster cohesion)
    ["search", "wiki"], ["graph-topic", "perf"], ["build", "infra"],
    // topic → session (most edges)
    ["ingest", "0193f8c2"], ["ingest", "0193b840"], ["ingest", "0193cf77"],
    ["search", "0193e2c4"], ["search", "0193b210"], ["search", "s-srch-1"],
    ["graph-topic", "0193df01"], ["graph-topic", "0193ce11"], ["graph-topic", "s-graph-1"],
    ["perf", "0193cf77"], ["perf", "0193df01"], ["perf", "s-perf-1"], ["perf", "0193f4a0"],
    ["build", "0193f841"], ["build", "0193ad88"],
    ["wiki", "0193d201"], ["wiki", "0193b210"], ["wiki", "s-wiki-1"], ["wiki", "0193be20"],
    ["wiki", "0193d990"],
    ["realtime", "0193c8a3"], ["realtime", "s-rt-1"],
    ["fonts", "0193dac8"],
    ["ux", "0193c40e"], ["ux", "s-ui-1"],
    ["infra", "s-perf-1"], ["infra", "0193ad88"],
    // session ↔ session (semantic similarity — Obsidian's "neighbours")
    ["0193f8c2", "0193cf77"], ["0193e2c4", "0193b210"], ["0193df01", "0193ce11"],
    ["0193d201", "0193be20"], ["0193b210", "s-wiki-1"], ["0193c8a3", "s-rt-1"],
    ["0193c40e", "s-ui-1"], ["0193d990", "s-rt-1"],
  ];

  // degree → node radius (Obsidian sizes by connection count)
  const degree = {};
  EDGES.forEach(([a, b]) => { degree[a] = (degree[a] || 0) + 1; degree[b] = (degree[b] || 0) + 1; });
  const baseR = (t) => t === "project" ? 7 : t === "topic" ? 4.5 : 2.8;
  const radius = (n) => baseR(n.type) + Math.min(6, (degree[n.id] || 0) * 0.55);

  const NodeStyle = {
    project: { fill: "var(--accent)",       glow: "var(--accent)" },
    topic:   { fill: "var(--info)",         glow: "var(--info)" },
    session: { fill: "var(--text-3)",       glow: "var(--text-2)" },
  };
  const VISIBLE = NODES.filter(n => filters[n.type]);
  const visIds = new Set(VISIBLE.map(n => n.id));
  const VIS_EDGES = EDGES.filter(([a, b]) => visIds.has(a) && visIds.has(b));

  // adjacency for hover highlight
  const adj = {};
  EDGES.forEach(([a, b]) => {
    (adj[a] = adj[a] || new Set()).add(b);
    (adj[b] = adj[b] || new Set()).add(a);
  });
  const isLit = (id) => !hover ? false : (id === hover || adj[hover]?.has(id));
  const isDim = (id) => hover && !isLit(id);

  const byId = Object.fromEntries(NODES.map(n => [n.id, n]));

  return (
    <div className="graph graph--obs" data-screen-label="05 graph">
      <div className="graph__obs-canvas">
        <svg viewBox="0 0 880 540" preserveAspectRatio="xMidYMid meet"
             className="graph__obs-svg">
          <defs>
            <radialGradient id="vignette" cx="50%" cy="50%" r="62%">
              <stop offset="0%" stopColor="rgba(0,0,0,0)" />
              <stop offset="80%" stopColor="rgba(0,0,0,0)" />
              <stop offset="100%" stopColor="rgba(0,0,0,.18)" />
            </radialGradient>
            <filter id="nodeGlow" x="-200%" y="-200%" width="500%" height="500%">
              <feGaussianBlur stdDeviation="3" result="b" />
              <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          {/* edges */}
          <g className="g-edges">
            {VIS_EDGES.map(([a, b], i) => {
              const A = byId[a], B = byId[b];
              const lit = hover && (a === hover || b === hover);
              const dim = hover && !lit;
              return (
                <line key={i} x1={A.x} y1={A.y} x2={B.x} y2={B.y}
                  stroke={lit ? "var(--accent)" : "var(--border)"}
                  strokeOpacity={lit ? 0.85 : dim ? 0.18 : 0.55}
                  strokeWidth={lit ? 1 : 0.7} />
              );
            })}
          </g>

          {/* nodes */}
          <g className="g-nodes">
            {VISIBLE.map(n => {
              const r = radius(n);
              const lit = isLit(n.id) || n.id === hover;
              const dim = isDim(n.id);
              const style = NodeStyle[n.type];
              const opacity = dim ? 0.28 : 1;
              return (
                <g key={n.id} transform={`translate(${n.x},${n.y})`}
                   className="g-node"
                   onMouseEnter={() => setHover(n.id)}
                   onMouseLeave={() => setHover(null)}
                   style={{ opacity }}>
                  {lit && (
                    <circle r={r + 6} fill={style.glow} opacity="0.18"
                            filter="url(#nodeGlow)" />
                  )}
                  <circle r={r}
                    fill={style.fill}
                    stroke={n.type === "project" ? "var(--bg)" : "transparent"}
                    strokeWidth={n.type === "project" ? 1.5 : 0} />
                  {showLabels && (n.type !== "session" || lit || !hover) && (
                    <text y={r + 11} textAnchor="middle"
                      className={"g-label g-label--" + n.type}
                      style={{
                        opacity: dim ? 0.4
                                 : n.type === "session" ? (lit ? 1 : 0.7) : 1
                      }}>
                      {n.label || n.id}
                    </text>
                  )}
                </g>
              );
            })}
          </g>

          <rect width="880" height="540" fill="url(#vignette)" pointerEvents="none" />
        </svg>
      </div>

      {/* sidebar (Obsidian-style filters) */}
      <aside className="graph__panel">
        <div className="gp-grp">
          <div className="eyebrow">Filters</div>
          <label className="gp-row">
            <input type="checkbox" checked={filters.project}
              onChange={() => setFilters({ ...filters, project: !filters.project })} />
            <span className="gp-dot" style={{ background: "var(--accent)" }} />
            <span>Projects</span>
            <span className="gp-n mono">4</span>
          </label>
          <label className="gp-row">
            <input type="checkbox" checked={filters.topic}
              onChange={() => setFilters({ ...filters, topic: !filters.topic })} />
            <span className="gp-dot" style={{ background: "var(--info)" }} />
            <span>Topics</span>
            <span className="gp-n mono">11</span>
          </label>
          <label className="gp-row">
            <input type="checkbox" checked={filters.session}
              onChange={() => setFilters({ ...filters, session: !filters.session })} />
            <span className="gp-dot" style={{ background: "var(--text-3)" }} />
            <span>Sessions</span>
            <span className="gp-n mono">203</span>
          </label>
        </div>

        <div className="gp-grp">
          <div className="eyebrow">Display</div>
          <label className="gp-row gp-row--toggle">
            <span>Show labels</span>
            <input type="checkbox" checked={showLabels}
              onChange={() => setShowLabels(!showLabels)} />
          </label>
          <div className="gp-slider">
            <div className="gp-slider__lbl"><span>Link force</span><span className="mono">0.62</span></div>
            <div className="gp-track"><div className="gp-thumb" style={{ left: "62%" }} /></div>
          </div>
          <div className="gp-slider">
            <div className="gp-slider__lbl"><span>Repel</span><span className="mono">0.48</span></div>
            <div className="gp-track"><div className="gp-thumb" style={{ left: "48%" }} /></div>
          </div>
          <div className="gp-slider">
            <div className="gp-slider__lbl"><span>Center</span><span className="mono">0.30</span></div>
            <div className="gp-track"><div className="gp-thumb" style={{ left: "30%" }} /></div>
          </div>
        </div>

        <div className="gp-grp">
          <div className="eyebrow">Stats</div>
          <div className="lg__stat"><span>Nodes</span><b className="mono">{VISIBLE.length} / {NODES.length}</b></div>
          <div className="lg__stat"><span>Edges</span><b className="mono">{VIS_EDGES.length} / {EDGES.length}</b></div>
          <div className="lg__stat"><span>Last build</span><b className="mono">3d</b></div>
        </div>

        {hover && (
          <div className="gp-grp gp-grp--hover">
            <div className="eyebrow">Hover</div>
            <div className="gp-hover">
              <span className="gp-dot" style={{ background: NodeStyle[byId[hover]?.type].fill }} />
              <span className="gp-hover__label">{byId[hover]?.label || byId[hover]?.id}</span>
            </div>
            <div className="gp-hover__meta mono">
              {byId[hover]?.type} · {(degree[hover] || 0)} links
            </div>
          </div>
        )}
      </aside>

      <div className="graph__controls">
        <button className="gc">−</button>
        <button className="gc">＋</button>
        <button className="gc">fit</button>
      </div>
    </div>
  );
}

/* ---------- Commands ---------- */
function RouteCommands({ onRun }) {
  const cmds = window.SECALL_DATA.COMMANDS;
  return (
    <div className="cmds" data-screen-label="06 commands">
      <div className="cmds__head">
        <h1 className="page__title">Commands</h1>
        <p className="page__sub">로컬에서 실행되는 백그라운드 작업입니다. 진행 중인 job 은 상단 배너에 노출됩니다.</p>
      </div>
      <div className="cmds__grid">
        {cmds.map(c => (
          <div key={c.key} className="cmd">
            <div className="cmd__hd">
              <h3 className="cmd__title">{c.label}</h3>
              <span className={"cmd__status cmd__status--" + c.status}>
                <span className="cmd__dot" />
                {c.status === "ok" ? "정상" : "오래됨"}
              </span>
            </div>
            <p className="cmd__desc">{c.desc}</p>
            <div className="cmd__meta">
              <div><span className="eyebrow">last run</span><div>{c.lastRun}</div></div>
              <div><span className="eyebrow">duration</span><div className="mono">{c.lastDuration}</div></div>
            </div>
            <div className="cmd__actions">
              <button className="btn btn--ghost">옵션</button>
              <button className="btn btn--primary" onClick={() => onRun(c)}>
                <IconPlay size={9} /> 실행
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.RouteDaily = RouteDaily;
window.RouteGraph = RouteGraph;
window.RouteCommands = RouteCommands;
