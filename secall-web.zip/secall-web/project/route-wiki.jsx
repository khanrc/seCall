// route-wiki.jsx — /wiki search + 3-mode + markdown body
const { useState: useState_W } = React;

function WikiResult({ r, active, onClick }) {
  return (
    <li className={"wr" + (active ? " wr--on" : "")} onClick={onClick}>
      <div className="wr__title">{r.title}</div>
      <div className="wr__excerpt">{r.excerpt}</div>
      <div className="wr__meta mono">{r.project} · score {r.score.toFixed(2)}</div>
    </li>
  );
}

function RouteWiki({ q, mode }) {
  const projects = window.SECALL_DATA.PROJECTS;
  const [active, setActive] = useState_W("secall");

  const results = q ? [
    { id: "r1", title: "ingest pipeline — chunk boundary 처리", excerpt: "tokio_util::LinesCodec 로 UTF-8 boundary 안전 split. 1MiB max line.", project: "secall", score: 0.91 },
    { id: "r2", title: "sse 재연결 백오프 정책",                  excerpt: "exponential 2^n cap 32s, jitter ±20%. missing event 재요청 안 함.", project: "secall", score: 0.78 },
    { id: "r3", title: "build 캐시 무효화 노트",                  excerpt: "cargo build.rs rerun-if-changed=web/dist. release 빌드 confirm.", project: "secall-web", score: 0.62 },
  ] : null;

  const md = `# secall

> A local wiki built from the conversations you have with terminal AI agents.

\`secall\` 은 Claude Code · Codex · Gemini CLI · claude.ai · ChatGPT 와 매일 주고받은 대화를
**로컬 SQLite + Obsidian-호환 vault** 로 정리하는 도구입니다.

## 구성

- **Ingest** — 에이전트별 로그 디렉터리를 watch · 파싱 · 정규화
- **Wiki** — 프로젝트 단위로 자동 위키 페이지 생성, 사용자 편집 보존
- **Search** — 키워드(SQLite FTS5), 시맨틱(HNSW), 두 결과의 hybrid rerank
- **Graph** — 페이지·세션·태그를 노드로 한 시맨틱 그래프

## 최근 변경

- \`0193f8c2\` — ingest 의 UTF-8 boundary 패치 (LinesCodec)
- \`0193e2c4\` — semantic search 인덱스 튜닝 — recall 0.92 / p95 18ms
- \`0193d201\` — obsidian frontmatter strict mode

## 디렉터리

\`\`\`
~/.secall/
  data.db                # SQLite 본체
  vault/                 # Obsidian-호환 마크다운
    secall/
      README.md
      sessions/
    secall-web/
\`\`\`

## 다음 작업

1. wiki 자동 cross-link threshold 재검토
2. graph layout worker 마이그레이션 마무리
3. daily 자동 생성 프롬프트 3-part 분리 검증`;

  return (
    <div className="layout-2pane" data-screen-label="03 wiki">
      <aside className="col-list">
        <div className="sl">
          <div className="tree">
            {results ? (
              <TreeSection title="results" count={results.length} badge={mode}>
                <ul className="tree__list">
                  {results.map((r, i) => (
                    <li key={r.id}
                      className={"tree__row tree__row--multi" + (i === 0 ? " tree__row--on" : "")}>
                      <span className="tree__rail" />
                      <span className="tree__multi">
                        <span className="tree__title">{r.title}</span>
                        <span className="tree__sub">{r.excerpt}</span>
                      </span>
                      <span className="tree__when mono">{r.score.toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
              </TreeSection>
            ) : (
              projects.map(p => (
                <TreeSection key={p.name} title={p.name} count={p.pages}
                  defaultOpen={p.name === active}>
                  <ul className="tree__list">
                    <li className={"tree__row" + (active === p.name ? " tree__row--on" : "")}
                      onClick={() => setActive(p.name)}>
                      <span className="tree__rail" />
                      <span className="tree__title">README</span>
                      <span className="tree__when mono">{p.updated}</span>
                    </li>
                    {Array.from({ length: Math.min(5, p.pages - 1) }).map((_, i) => (
                      <li key={i} className="tree__row" onClick={() => setActive(p.name)}>
                        <span className="tree__rail" />
                        <span className="tree__title">{["sessions", "ingest", "search", "graph", "build"][i]}</span>
                        <span className="tree__when mono">·</span>
                      </li>
                    ))}
                  </ul>
                </TreeSection>
              ))
            )}
          </div>
        </div>
      </aside>
      <main className="col-read">
        <div className="pane pane--read pane--prose">
          <div className="pane__head pane__head--wiki">
            <div className="pane__crumbs">
              <span className="eyebrow">Wiki</span>
              <span className="pane__sep">/</span>
              <span className="pane__proj mono">{active}</span>
            </div>
            <div className="pane__actions">
              <span className="pane__when">last modified · 2026-05-08 09:32</span>
              <button className="btn btn--ghost">편집</button>
              <button className="btn btn--ghost">vault 열기</button>
            </div>
          </div>
          <article className="prose prose--wiki">
            {renderMarkdown(md)}
          </article>
        </div>
      </main>
    </div>
  );
}

/* tiny markdown renderer — h1-3, paragraphs, code, blockquote, lists */
function renderMarkdown(src) {
  const lines = src.split("\n");
  const out = [];
  let i = 0, key = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.startsWith("# "))      { out.push(<h1 key={key++}>{ln.slice(2)}</h1>); i++; }
    else if (ln.startsWith("## ")) { out.push(<h2 key={key++}>{ln.slice(3)}</h2>); i++; }
    else if (ln.startsWith("### ")) { out.push(<h3 key={key++}>{ln.slice(4)}</h3>); i++; }
    else if (ln.startsWith("> "))  { out.push(<blockquote key={key++}>{ln.slice(2)}</blockquote>); i++; }
    else if (ln.startsWith("```")) {
      const buf = []; i++;
      while (i < lines.length && !lines[i].startsWith("```")) { buf.push(lines[i]); i++; }
      i++;
      out.push(<pre key={key++} className="code"><code>{buf.join("\n")}</code></pre>);
    }
    else if (/^[\-\*] /.test(ln)) {
      const buf = [];
      while (i < lines.length && /^[\-\*] /.test(lines[i])) { buf.push(lines[i].slice(2)); i++; }
      out.push(<ul key={key++}>{buf.map((b, j) => <li key={j}>{inlineMd(b)}</li>)}</ul>);
    }
    else if (/^\d+\. /.test(ln)) {
      const buf = [];
      while (i < lines.length && /^\d+\. /.test(lines[i])) { buf.push(lines[i].replace(/^\d+\. /, "")); i++; }
      out.push(<ol key={key++}>{buf.map((b, j) => <li key={j}>{inlineMd(b)}</li>)}</ol>);
    }
    else if (ln.trim() === "") { i++; }
    else { out.push(<p key={key++}>{inlineMd(ln)}</p>); i++; }
  }
  return out;
}
function inlineMd(s) {
  const parts = [];
  let rest = s, key = 0;
  const re = /`([^`]+)`|\*\*([^*]+)\*\*/;
  while (rest.length) {
    const m = rest.match(re);
    if (!m) { parts.push(rest); break; }
    if (m.index > 0) parts.push(rest.slice(0, m.index));
    if (m[1] != null) parts.push(<code key={key++} className="ic">{m[1]}</code>);
    else parts.push(<strong key={key++}>{m[2]}</strong>);
    rest = rest.slice(m.index + m[0].length);
  }
  return parts;
}

window.RouteWiki = RouteWiki;
