// app.jsx — root: routing, theme, tweaks, job state, hotkeys
const { useState, useEffect, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": true,
  "accent": "teal",
  "density": "regular",
  "showJob": false
}/*EDITMODE-END*/;

function useTheme(dark, accent) {
  useEffect(() => {
    const cls = document.documentElement.classList;
    cls.toggle("dark", dark);
    cls.remove("accent-teal", "accent-sage", "accent-amber", "accent-indigo");
    if (accent !== "teal") cls.add("accent-" + accent);
  }, [dark, accent]);
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  useTheme(t.dark, t.accent);

  const [route, setRoute] = useState("sessions");
  const [selectedId, setSelectedId] = useState("0193f8c2");
  const [hotkey, setHotkey]   = useState(false);
  const [toast, setToast]     = useState(null);

  // lifted search state (header search)
  const [q, setQ] = useState("");
  const [searchMode, setSearchMode] = useState("keyword");
  useEffect(() => {
    if (route === "wiki") setSearchMode((m) => m === "semantic" ? "semantic" : "hybrid");
    else if (route === "sessions") setSearchMode((m) => m === "hybrid" ? "keyword" : m);
  }, [route]);

  // job state — driven from Tweaks toggle
  const [job, setJob] = useState(null);
  useEffect(() => {
    if (!t.showJob) { setJob(null); return; }
    const phases = [
      { p: 0.05, phase: "scan vault" },
      { p: 0.18, phase: "parse · 47 / 218" },
      { p: 0.32, phase: "parse · 96 / 218" },
      { p: 0.48, phase: "embed · 102 / 218" },
      { p: 0.62, phase: "embed · 146 / 218" },
      { p: 0.78, phase: "rerank · 4 / 7" },
      { p: 0.92, phase: "write · vault/" },
      { p: 1.0,  phase: "done" },
    ];
    let i = 0;
    setJob({ label: "Wiki Update", phase: phases[0].phase, progress: phases[0].p });
    const id = setInterval(() => {
      i = (i + 1) % phases.length;
      setJob({ label: "Wiki Update", phase: phases[i].phase, progress: phases[i].p });
    }, 1800);
    return () => clearInterval(id);
  }, [t.showJob]);

  // global hotkeys
  useEffect(() => {
    let pending = null, pendingTs = 0;
    const onKey = (e) => {
      const tag = (e.target?.tagName || "").toLowerCase();
      if (["input", "textarea"].includes(tag)) return;
      if (e.key === "?" && e.shiftKey) { setHotkey(true); e.preventDefault(); return; }
      if (e.key === "/") { e.preventDefault(); document.querySelector(".hsb__input, .sb__input")?.focus(); return; }
      if (e.key === "g") { pending = "g"; pendingTs = Date.now(); return; }
      if (pending === "g" && Date.now() - pendingTs < 800) {
        const map = { s: "sessions", w: "wiki", d: "daily", g: "graph", c: "commands" };
        if (map[e.key]) { setRoute(map[e.key]); pending = null; return; }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  let content = null;
  if (route === "sessions")      content = <RouteSessions selectedId={selectedId} onSelect={setSelectedId} q={q} mode={searchMode} />;
  else if (route === "wiki")     content = <RouteWiki q={q} mode={searchMode} />;
  else if (route === "daily")    content = <RouteDaily />;
  else if (route === "graph")    content = <RouteGraph />;
  else if (route === "commands") content = <RouteCommands onRun={(c) => setToast({ msg: c.label + " 시작됨", kind: "ok" })} />;

  const showSearch = route === "sessions" || route === "wiki";
  const searchSlot = showSearch ? (
    <HeaderSearch
      q={q} onQ={setQ}
      mode={searchMode} onMode={setSearchMode}
      modes={route === "wiki" ? ["keyword", "semantic", "hybrid"] : ["keyword", "semantic"]}
    />
  ) : null;

  return (
    <div className="app-shell">
      <TopNav route={route} onRoute={setRoute}
        onTheme={() => setTweak("dark", !t.dark)}
        dark={t.dark}
        onHotkey={() => setHotkey(true)}
        searchSlot={searchSlot} />
      <JobBanner job={job} onCancel={() => { setTweak("showJob", false); setToast({ msg: "Wiki Update 취소됨", kind: "err" }); }} />
      <div className="app-main">
        {content}
      </div>

      <HotkeyHelpDialog open={hotkey} onClose={() => setHotkey(false)} />
      <Toast toast={toast} onDone={() => setToast(null)} />

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakToggle  label="Dark mode"   value={t.dark}    onChange={(v) => setTweak("dark", v)} />
        <TweakRadio   label="Accent"      value={t.accent}
                      options={["teal", "sage", "amber", "indigo"]}
                      onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="State" />
        <TweakToggle  label="Job 진행 중" value={t.showJob} onChange={(v) => setTweak("showJob", v)} />
        <TweakButton  label="단축키 모달"  onClick={() => setHotkey(true)} />
        <TweakButton  label="토스트 (성공)" onClick={() => setToast({ msg: "Sync 완료 · 12 sessions", kind: "ok" })} />
        <TweakButton  label="토스트 (실패)" onClick={() => setToast({ msg: "Ingest 실패 · timeout", kind: "err" })} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
